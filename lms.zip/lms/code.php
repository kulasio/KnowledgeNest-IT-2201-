<?php
$javaactivity1 = "aB3cD4";
$javaactivity2 = "eF5gH6";
$javaactivity3 = "iJ7kL8";
$javaquiz1 = "mN9oP0";
$javaquiz2 = "qR1sT2";
$javaquiz3 = "uV3wX4";
$javame = "yZ5aB6";
$javafe = "cD7eF8";

$javaSactivity1 = "aB3cD4";
$javaSactivity2 = "eF5gH6";
$javaSactivity3 = "iJ7kL8";
$javaSquiz1 = "mN9oP0";
$javaSquiz2 = "qR1sT2";
$javaSquiz3 = "uV3wX4";
$javaSme = "yZ5aB6";
$javaSfe = "cD7eF8";

$htmlactivity1 = "aB3cD4";
$htmlactivity2 = "eF5gH6";
$htmlactivity3 = "iJ7kL8";
$htmlquiz1 = "mN9oP0";
$htmlquiz2 = "qR1sT2";
$htmlquiz3 = "uV3wX4";
$htmlme = "yZ5aB6";
$htmlfe = "cD7eF8";

$cssactivity1 = "aB3cD4";
$cssactivity2 = "eF5gH6";
$cssactivity3 = "iJ7kL8";
$cssquiz1 = "mN9oP0";
$cssquiz2 = "qR1sT2";
$cssquiz3 = "uV3wX4";
$cssme = "yZ5aB6";
$cssfe = "cD7eF8";

$cppactivity1 = "aB3cD4";
$cppactivity2 = "eF5gH6";
$cppactivity3 = "iJ7kL8";
$cppquiz1 = "mN9oP0";
$cppquiz2 = "qR1sT2";
$cppquiz3 = "uV3wX4";
$cppme = "yZ5aB6";
$cppfe = "cD7eF8";


// Repeat the same for other languages

$error_message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_input = $_POST['code'];

    // Check if user input matches any of the codes
    if (
        $user_input == $javaactivity1
    ) {
        // Redirect to Google Form for Java
        header("Location: https://docs.google.com/forms/d/e/1FAIpQLSeDOtgsd-Z1tQdd8SVF8GmpNP0mPP2S6DKY8Dd9d4kS9yAK8Q/viewform?usp=sharing");
        exit();
    }
    elseif(
      $user_input == $javaactivity2
    ){
      header("Location: https://docs.google.com/forms/d/e/1FAIpQLSc2XbGpiGvqSzDZTD6fnOZqLgdZogXgJU2GtwBYhQB24zjFvA/viewform?usp=sf_link ");
        exit();
    }
    elseif(
      $user_input == $javaactivity3
    ){
      header("Location: https://docs.google.com/forms/d/e/1FAIpQLSeRsabS8KMn0IU4J6W6OL2TO5EU8fUZ71_-KgBXTIgpqGyc1w/viewform?usp=sf_link ");
        exit();
    }
    elseif(
      $user_input == $javaquiz1
    ){
      header("Location: https://docs.google.com/forms/d/e/1FAIpQLSeDOtgsd-Z1tQdd8SVF8GmpNP0mPP2S6DKY8Dd9d4kS9yAK8Q/viewform?usp=sharing ");
        exit();
    }
    elseif(
      $user_input == $javaquiz2
    ){
      header("Location: https://docs.google.com/forms/d/e/1FAIpQLSermZh9zZgeyJTbZcwYAurIkC-YcuYrWc9OBtrJIBZM7-6heQ/viewform?usp=sf_link ");
        exit();
    }
    elseif(
      $user_input == $javaquiz3
    ){
      header("Location: https://docs.google.com/forms/d/e/1FAIpQLSekFduU9EErXhfAnyVGZ0JQ3l19tLV5aenqbGAvZgikH5ZCgQ/viewform?usp=sf_link ");
        exit();
    }
    elseif(
      $user_input == $javame
    ){
      header("Location: https://docs.google.com/forms/d/e/1FAIpQLSeeYEo72pYBbzP5co71uGI8tcebelj7gB9gu8b_DJnKA4_t_w/viewform?usp=sf_link ");
        exit();
    }
    elseif(
      $user_input == $javafe
    ){
      header("Location: https://docs.google.com/forms/d/e/1FAIpQLSc4WPsVD4V2vRlK9v9tZOcTPdJm5u_1rhuHnynrCzQRj85Qdg/viewform?usp=sf_link ");
        exit();
    }
    elseif(
      $user_input == $javaSactivity1
    ){
      header("Location: JAVASCRIPT ACT 1
      https://docs.google.com/forms/d/e/1FAIpQLSer3ldSj3eGBct5DZtGtcdpga0HmCpJcEKZjF5KM5a7g1CQEQ/viewform?usp=sharing ");
        exit();
    }

     else {
        // Set error message if input code is incorrect
        $error_message = "Invalid code. Please try again.";
    }

    // Add similar checks for other languages
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        * {
            font-family: "Poppins", sans-serif;
        }
    </style>
    <link rel="stylesheet" href="code.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>

<body>
<div class="wrapper">
<form id="index.php" method="post">
  <h1>Enter Code</h1>
      <form action="index.php" method="post">
            <div class="input-box">
            <input type="text" id="code" name="code" placeholder="Ex: abc123" required>
            <br><button class="btn">Log In</button>
            <?php if (!empty($error_message)) : ?>
                <p style="color: red;"><?php echo $error_message; ?></p>
            <?php endif; ?>
        </form>
    </div>
</form>
</div>
</body>
</html>