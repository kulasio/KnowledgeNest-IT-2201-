<?php
include 'config/database.php';
?>
<?php
session_start();
?>

<! DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Class</title>
    <style>
        * {
            font-family: "Poppins", sans-serif;
        }
    </style>
    <link rel="stylesheet" href="class.css">
</head>

<body>
<div class="hero">
        <nav>
          <img src="images/logoimg.jpg" alt="Logo" class="logo">
          <h1>KnowledgeNest LMS</h1>
          <ul>
         <li><a href="homepage.php"><h3>Home</h3></a></li>
         <li><a href="class.php"><h3>E-Library</h3></a></li>
         <li><a href="activites.php"><h3>Activities</h3></a></li>

        </ul>
        <img src="images/700kfb.png" class="user-pic" onclick="toggleMenu()">
       
        <div class="sub-menu-wrap" id="subMenu">
        <div class="sub-menu">
            <div class="user-info">
                <img src="images/700kfb.png">
                <?php if(isset($_SESSION['username'])): ?>
                    <h2><?php echo $_SESSION['username']; ?></h2>
                <?php endif; ?>
            </div>
            <hr>
            <a href="AccountConfig.php" class="sub-menu-link">
                <img src="images/setting.png">
                <p>Account Settings</p>
                <span>></span>
            </a>
            <a href="#.php" class="sub-menu-link">
                <img src="images/illustration-of-book-icon-free-vector.jpg">
                <p>View Grades</p>
                <span>></span>
            </a>
            <a href="feedback.php" class="sub-menu-link">
                <img src="images/help.png">
                <p>Feedback</p>
                <span>></span>
            </a>
            <a href="index.php" class="sub-menu-link">
                <img src="images/logout.png">
                <p>Logout</p>
                <span>></span>
            </a>
        </div>
    </div>
      </nav>
</div>
<script>
  let subMenu = document.getElementById("subMenu");
  
  function toggleMenu(){
    subMenu.classList.toggle("open-menu");
  }

</script>
  <div class = "container1">
    
  </div>
</body>
</html>