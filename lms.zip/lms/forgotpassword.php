
<?php
include 'config/conn.php';

// Define variables and initialize with empty values
$username = $new_password = $security_answer = "";

// Processing form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate username and new password
    $username = trim($_POST["username"]);
    $new_password = trim($_POST["new_password"]);
    $security_answer = trim($_POST["security_answer"]);

    // Check if the security answer is correct
    $sql = "SELECT s_recanswer FROM student WHERE s_username = ?";
    $stmt = $connection->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($stored_answer);
        $stmt->fetch();

        if ($security_answer == $stored_answer) {
            // Update the password
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $update_sql = "UPDATE student SET s_password = ? WHERE s_username = ?";
            $update_stmt = $connection->prepare($update_sql);
            $update_stmt->bind_param("ss", $hashed_password, $username);
            if ($update_stmt->execute()) {
                echo '<div class="alert alert-success" role="alert">Password updated successfully!</div>';
            } else {
                echo '<div class="alert alert-danger" role="alert">Error updating password: ' . $update_stmt->error . '</div>';
            }
        } else {
            echo '<div class="alert alert-danger" role="alert">Incorrect answer to security question!</div>';
        }
    } else {
        echo '<div class="alert alert-danger" role="alert">Username not found!</div>';
    }

    // Close statement
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password</title>
    <style>
        * {
            font-family: "Poppins", sans-serif;
        }
    </style>
    <link rel="stylesheet" href="forgotpassword.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
    <div class="container mt-5">
        <h2>Change Password</h2>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group">
                <input type="text" class="form-control" id="username" name="username" placeholder="Username" required>
                <i class='bx bxs-user'></i>
            </div>
            <div class="form-group">
                <input type="text" class="form-control" id="security_answer" name="security_answer" placeholder="What is the name of your pet?" required>
                <i class='bx bxs-dog'></i>
            </div>
            <div class="form-group">
                <input type="password" class="form-control" id="new_password" name="new_password" placeholder="New Password" required>
                <i class='bx bx-lock' ></i>
            </div>
            <button type="submit" class="btn btn-primary">Change Password</button>
        </form>
    </div>
</body>
</html>
