<?php
include 'config/database.php';
?>
<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback</title>
    <style>
        * {
            font-family: "Poppins", sans-serif;
        }
    </style>
    <link rel="stylesheet" href="feedback.css">
</head>

<body>
<div class="hero">
        <nav>
          <img src="images/logoimg.jpg" alt="Logo" class="logo">
          <h1>KnowledgeNest LMS</h1>
          <ul>
         <li><a href="homepage.php"><h3>Home</h3></a></li>
         <li><a href="activites.php"><h3>Activities</h3></a></li>

        </ul>
        <img src="images/OIP.jpg" class="user-pic" onclick="toggleMenu()">
       
        <div class="sub-menu-wrap" id="subMenu">
        <div class="sub-menu">
            <div class="user-info">
                <img src="images/OIP.jpg">
                <?php if(isset($_SESSION['username'])): ?>
                    <h2><?php echo $_SESSION['username']; ?></h2>
                <?php endif; ?>
            </div>
            <hr>
            <a href="AccountConfig.php" class="sub-menu-link">
                <img src="images/setting.png">
                <p>Account Settings</p>
                <span>></span>
            </a>

            <a href="#.php" class="sub-menu-link">
                <img src="images/book-icon-line-vector.jpg">
                <p>E-library</p>
                <span>></span>
            </a>


            <a href="#.php" class="sub-menu-link">
                <img src="images/illustration-of-book-icon-free-vector.jpg">
                <p>View Grades</p>
                <span>></span>
            </a>
            <a href="feedback.php" class="sub-menu-link">
                <img src="images/help.png">
                <p>Feedback</p>
                <span>></span>
            </a>
            <a href="index.php" class="sub-menu-link">
                <img src="images/logout.png">
                <p>Logout</p>
                <span>></span>
            </a>
        </div>
    </div>
      </nav>
</div>
<?php

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "lms_final";

    // Create connection
    $connection = new mysqli($servername, $username, $password, $database);

    // Check connection
    if ($connection->connect_error) {
        die("Connection failed: " . $connection->connect_error);
    }

    // Initialize variables with default values
    $studentid = isset($_POST['studentid']) ? $_POST['studentid'] : "";
    $course_id = isset($_POST['course_id']) ? $_POST['course_id'] : "";
    $s_contactnumber = isset($_POST['contactnumber']) ? $_POST['contactnumber'] : "";
    $s_email = isset($_POST['email']) ? $_POST['email'] : "";
    $feedbacktext = isset($_POST['feedback']) ? $_POST['feedback'] : "";

    // Prepare a statement
    $sql = "INSERT INTO feedback (student_id, course_id, s_contactnumber, s_email, feedbacktext) 
            VALUES (?, ?, ?, ?, ?)";

    if ($stmt = $connection->prepare($sql)) {
        // Bind parameters
        $stmt->bind_param("sssss", $studentid, $course_id, $s_contactnumber, $s_email, $feedbacktext);

        // Execute the statement
        if ($stmt->execute()) {
            // Success message
            echo '<div class="success-message">Feedback submitted successfully!</div>';
        } else {
            // Display error message if execution fails
            echo "Error: " . $stmt->error;
        }

        // Close statement
        $stmt->close();
    } else {
        // Display error message if preparation fails
        echo "Error: " . $connection->error;
    }

    // Close connection
    $connection->close();
}
?>

    <div class="container my-5">
        <h2>Feedback Form</h2>
        <form action="feedback.php" method="post">
            <div class="student-container">
                <div class="student-form-group">
                    <label for="studentid">Student Id</label>
                    <input type="text" id="studentid" name="studentid" placeholder="Enter your student ID">
                </div>
            </div>
            <div class="form-group">
                <label for="course_id">Course Id</label>
                <input type="text" id="course_id" name="course_id" placeholder="Enter your Course's ID">
            </div>
            <div class="form-group">
                <label for="contactnumber">Contact Number</label>
                <input type="text" id="contactnumber" name="contactnumber" placeholder="Enter your Contact Number">
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="text" id="email" name="email" placeholder="Enter your email">
            </div>
            <div class="form-group">
                <label for="feedback">Feedback</label>
                <textarea id="feedback" name="feedback" rows="4" placeholder="Your feedback here..."></textarea>
            </div>
            <div class="form-group">
                <button type="submit" >Submit</button>
            </div>
        </form>
    </div>

    <script>
        let subMenu = document.getElementById("subMenu");
        
        function toggleMenu(){
            subMenu.classList.toggle("open-menu");
        }
    </script>
</body>
</html>
