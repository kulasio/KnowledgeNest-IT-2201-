<?php


// Function to get users from the database
function getUsers($conn) {
    $sql = "SELECT * FROM users";
    $result = $conn->query($sql);
    $users = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $users[] = $row;
        }
    }
    return $users;
}

// Handle CRUD operations
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    // Create a new user
    if ($_POST['action'] === 'create') {
        createNewUser($conn);
    }
    // Update an existing user
    elseif ($_POST['action'] === 'update') {
        updateExistingUser($conn);
    }
       // Delete a user by srcode
       elseif ($_POST['action'] === 'delete' && isset($_POST['deleteSrcode'])) {
        deleteBySrcode($conn);
    }
}

// Function to create a new user
function createNewUser($conn) {
    $srcode = $_POST['srcode'];
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];

    // Do not include user_id in the INSERT statement (assuming it's auto-increment)
    $sql = "INSERT INTO users (srcode, first_name, last_name) VALUES ('$srcode', '$firstName', '$lastName')";
    if ($conn->query($sql) === TRUE) {
        header('Location: dashboard.php'); // Redirect after insertion
        exit();
    } else {
        echo 'Error: ' . $conn->error;
    }
}

// Function to update an existing user
function updateExistingUser($conn) {
    $userId = $_POST['user_id'];
    $srcode = $_POST['srcode'];
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];

    $sql = "UPDATE users SET srcode='$srcode', first_name='$firstName', last_name='$lastName' WHERE userid=$userId";
    if ($conn->query($sql) === TRUE) {
        header('Location: dashboard.php'); // Redirect after update
        exit();
    } else {
        echo 'Error: ' . $conn->error;
    }
}

// Function to delete a user by srcode
function deleteBySrcode($conn) {
    $srcode = $_POST['deleteSrcode'];

    // Prepare the delete statement
    $stmt = $conn->prepare("DELETE FROM users WHERE srcode = ?");

    if ($stmt) {
        // Bind the srcode parameter
        $stmt->bind_param("s", $srcode);

        // Execute the statement
        if ($stmt->execute()) {
            // Redirect after successful deletion
            header('Location: dashboard.php?delete=success');
            exit();
        } else {
            // Error executing the statement
            echo 'Error deleting user: ' . $stmt->error;
        }
    } else {
        // Error preparing the statement
        echo 'Error preparing statement: ' . $conn->error;
    }
}
?>
