<?php
include 'config/database.php';

// Define variables and initialize with empty values
$current_username = $current_password = $new_username = $new_password = "";

// Processing form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate current username and password
    $current_username = trim($_POST["current_username"]);
    $current_password = trim($_POST["current_password"]);

    // Validate new username and password
    $new_username = trim($_POST["new_username"]);
    $new_password = trim($_POST["new_password"]);

    // SQL query to check if the current username and password match
    $sql = "SELECT * FROM student WHERE s_username = ? AND s_password = ?";
    
    if ($stmt = $conn->prepare($sql)) {
        // Bind variables to the prepared statement as parameters
        $stmt->bind_param("ss", $current_username, $current_password);

        // Attempt to execute the prepared statement
        if ($stmt->execute()) {
            // Store result
            $stmt->store_result();

            // Check if the current username and password exist in the database
            if ($stmt->num_rows == 1) {
                // SQL query to update username and password
                $update_sql = "UPDATE student SET s_username = ?, s_password = ? WHERE s_username = ? AND s_password = ?";
                
                if ($update_stmt = $conn->prepare($update_sql)) {
                    // Bind variables to the prepared statement as parameters
                    $update_stmt->bind_param("ssss", $new_username, $new_password, $current_username, $current_password);

                    // Attempt to execute the prepared statement
                    if ($update_stmt->execute()) {
                        echo "Successfully change";
                        header("location: Accountconfig.php");
                        exit();
                    } else {
                        // Display an error message if the query fails
                        echo "Oops! Something went wrong. Please try again later.";
                    }

                    // Close statement
                    $update_stmt->close();
                }
            } else {
                // Display an error message if the current username and password do not match
                echo "Incorrect current username or password.";
            }
        } else {
            // Display an error message if the query fails
            echo "Oops! Something went wrong. Please try again later.";
        }

        // Close statement
        $stmt->close();
    }

    // Close connection
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Username and Password</title>
    <link rel="stylesheet" href="Accountconfig.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
    <div class="container mt-5">
        <h2>Change Username and Password</h2>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group">
                <input type="text" class="form-control" id="current_username" name="current_username" placeholder="Current Username" required>
                <i class='bx bxs-user'></i>
            </div>
            <div class="form-group">
                <input type="password" class="form-control" id="current_password" name="current_password" placeholder="Curent Password" required>
                <i class='bx bx-lock' ></i>
            </div>
            <div class="form-group">
                <input type="text" class="form-control" id="new_username" name="new_username" placeholder="New Username" required>
                <i class='bx bxs-user-rectangle'></i>
            </div>
            <div class="form-group">
                <input type="password" class="form-control" id="new_password" name="new_password" placeholder= "New Password" required>
                <i class='bx bxs-lock' ></i>
            </div>
            <button type="submit" class="btn btn-primary">Save Changes</button>
        </form>
    </div>
</body>
</html>
