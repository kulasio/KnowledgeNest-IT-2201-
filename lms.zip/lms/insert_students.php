<?php
include 'config/database.php';
?>
<?php
session_start();

// Check if the form is submitted
if(isset($_POST['submit'])) {
    // Get form data
    $student_code = $_POST['student_code'];
    $firstname = $_POST['firstname'];
    $middlename = $_POST['middlename']; // Added middlename field
    $lastname = $_POST['lastname'];
    $username = $_POST['username']; // Added username field
    $password = $_POST['password']; // Added password field
    $gender = $_POST['gender']; // Added gender field
    $address = $_POST['address'];
    // Get course ID from session
    $course_id = $_SESSION['course_id'];

    // Insert student data into the database
    $sql = "INSERT INTO students (student_code, firstname, middlename, lastname, username, password, gender, address, course_id, date_created) 
            VALUES ('$student_code', '$firstname', '$middlename', '$lastname', '$username', '$password', '$gender', '$address', $course_id, CURRENT_TIMESTAMP)";
    
    if ($conn->query($sql) === TRUE) {
        // Redirect back to Adminclass.php after successful insertion
        header('Location: Adminclass.php');
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>