<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Student</title>
    <style>
        * {
            font-family: "Poppins", sans-serif;
        }
    </style>
    <link rel="stylesheet" href="add_students.css">
</head>
<body>
<div class="container">
    <h2>Add Student</h2>
    <form action="insert_students.php" method="post">
        <input type="text" name="firstname" placeholder="First Name" required><br>
        <input type="text" name="middlename" placeholder="Middle Name" required><br>
        <input type="text" name="lastname" placeholder="Last Name" required><br>
        <input type="text" name="student_code" placeholder="Student ID" required><br>
        <input type="text" name="username" placeholder="Username" required><br>
        <input type="password" name="password" placeholder="Password" required><br>
        <label for="gender">Gender:</label>
        <select name="gender" id="gender">
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Other">Other</option>
        </select><br><br>
        <textarea name="address" placeholder="Address" required></textarea><br>
        <button type="submit" name="submit">Add Student</button>
    </form>
</div>
</body>
</html>
