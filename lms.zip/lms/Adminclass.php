<?php
include 'config/database.php';
?>
<?php
session_start();
?>
<! DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Adminactivities.css">
    <title>Class</title>
    <style>
        * {
            font-family: "Poppins", sans-serif;
        }
    </style>
    <link rel="stylesheet" href="Adminclass.css">
</head>

<body>
<div class="hero">
      <nav>
      <img src="images/logoimg.jpg" alt="Logo" class="logo">
        <h1>KnowledgeNest LMS</h1>
        <ul>
         <li><a href="Adminclass.php"><h3>Class</h3></a></li>
          <li><a href="Adminfeedback.php"><h3>Feedback</h3></a></li>

        </ul>
        <img src="images/700kfb.png" class="user-pic" onclick="toggleMenu()">
       
        <div class="sub-menu-wrap" id="subMenu">
        <div class="sub-menu">
            <div class="user-info">
                <img src="images/700kfb.png">
                <?php if(isset($_SESSION['username'])): ?>
                    <h2><?php echo $_SESSION['username']; ?></h2>
                <?php endif; ?>
            </div>
            <hr>
            <a href="AccountConfig.php" class="sub-menu-link">
                <img src="images/setting.png">
                <p>Account Settings</p>
                <span>></span>
            </a>
            <a href="feedback.php" class="sub-menu-link">
                <img src="images/help.png">
                <p>Feedback</p>
                <span>></span>
            </a>
            <a href="index.php" class="sub-menu-link">
                <img src="images/logout.png">
                <p>Logout</p>
                <span>></span>
            </a>
        </div>
    </div>
      </nav>
</div>
<div class = "container my-5">
        <h2>View Class</h2>
        <button type="submit" name="submit" class="btn">Add Student</button>
        <br>
        <table class="table">
            <thead>
                <tr>
                <th>#</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Student ID</th>
                <tr>
            </thead>
            <tbody>
                <?php
                $servername = "localhost";
                $username = "root";
                $password = "";
                $database = "lms_final";

                $connection = new mysqli($servername, $username, $password, $database);

                if ($connection->connect_error) {
                    die("Connection failed: " . $connection->connect_error);
                }

                $course_id = $_SESSION['course_id'];

                $sql = "SELECT * FROM students WHERE course_id = $course_id";
                $results = $connection->query($sql);

                if (!$results) {
                     die("Invalid query: " . $connection->error);
                }

                while ($row = $results->fetch_assoc()) {
                    echo "
                    <tr>
                         <td>$row[id]</td>
                         <td>$row[firstname]</td>
                         <td>$row[lastname]</td>
                         <td>$row[student_code]</td>
                    </tr>
                    ";
                }
                ?>

                
                
            </tbody>            
                        
        </table>
                
    <div>
<script>
  let subMenu = document.getElementById("subMenu");
  
  function toggleMenu(){
    subMenu.classList.toggle("open-menu");
  }

</script>
  <div class = "container1">
    
  </div>
</body>
</html>

