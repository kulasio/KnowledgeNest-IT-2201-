<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>crudoperation</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class = "container my-5">
        <h2>View Grade</h2>
        <br>
        <table class="table">
            <thead>
                <tr>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Srcode</th>
                    <th>Quiz 1</th>
                    <th>Quiz 2</th> 
                    <th>Quiz 3</th>
                    <th>ACT 1</th>
                    <th>ACT 2</th>
                    <th>ACT 3</th>
                    <th>Midterm</th>
                    <th>Action</th>
                <tr>
            </thead>
            <tbody>
                <?php
                $servername = "localhost";
                $username = "root";
                $password = "";
                $database = "crudoperation";

                $connection = new mysqli($servername, $username, $password, $database);

                if ($connection->connect_error) {
                    die("Connection failed: " . $connection->connect_error);
                }

                $sql = "SELECT * FROM users";
                $results = $connection->query($sql);

                if (!$results) {
                     die("Invalid query: " . $connection->error);
                }

                while ($row = $results->fetch_assoc()) {
                    echo "
                    <tr>
                         <td>$row[First_name]</td>
                         <td>$row[last_name]</td>
                         <td>$row[srcode]</td>
                         <td>$row[Quiz1]</td>
                         <td>$row[Quiz2]</td>
                         <td>$row[Quiz3]</td>
                         <td>$row[ACT1]</td>
                         <td>$row[ACT2]</td>
                         <td>$row[ACT3]</td>
                         <td>$row[Midterm]</td>
                         <td>

                            <a class='btn btn primary btn-sm' href='/crudoperation/edit.php?userid=$row[userid]'>Input</a>
                            <a class='btn btn danger btn-sm' href='/crudoperation/delete.php?userid=$row[userid]'>Delete</a>
                        </td>
                    </tr>
                    ";
                }
                ?>

                
                
            </tbody>            
                        
        </table>
                
    <div>
</body>
</html>