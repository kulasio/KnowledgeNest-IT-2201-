<?php
if ( isset($_GET["userid"]) ) {
    $userid = $_GET["userid"];

    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "lms_final";

    $connection = new mysqli($servername, $username, $password, $database);

    $sql = "DELETE FROM student WHERE studentid=$userid";
    $result = $connection->query($sql);

}

header("location: /lms/class.php");
exit;
?>