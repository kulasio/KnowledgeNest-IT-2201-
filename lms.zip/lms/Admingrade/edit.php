<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "lms_final";

try {
    $pdo = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}

$userid = "";
$First_name = "";
$last_name = "";
$srcode = "";
$Quiz1 = "";
$Quiz2 = "";
$Quiz3 = "";
$ACT1 = "";
$ACT2 = "";
$ACT3 = "";
$Midterm  = "";

$errorMessage = "";
$successMessage = "";

if ($_SERVER['REQUEST_METHOD'] == 'GET') {

    if (!isset($_GET["userid"])) {
        header("location: lms/Adminclass");
        exit;
    }

    $userid = $_GET["userid"];

    $stmt = $pdo->prepare("SELECT * FROM grades WHERE userid = :userid");
    $stmt->bindParam(':userid', $userid);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$row) {
        header("location: lms/Adminclass.php");
        exit;
    }
    $userid = $row["userid"];
    $First_name = $row["First_name"];
    $last_name = $row["last_name"];
    $srcode = $row["studentid"];
    $Quiz1 = $row["Quiz1"];
    $Quiz2 = $row["Quiz2"];
    $Quiz3 = $row["Quiz3"];
    $ACT1 = $row["ACT1"];
    $ACT2 = $row["ACT2"];
    $ACT3 = $row["ACT3"];
    $Midterm = $row["Midterm"];

    
} else 
    {

        $userid = $_POST["userid"];
        $First_name = $_POST["First_name"];
        $last_name = $_POST["last_name"];
        $srcode = $_POST["Srcode"];
        $Quiz1 = $_POST["Quiz1"];
        $Quiz2 = $_POST["Quiz2"];
        $Quiz3 = $_POST["Quiz3"];
        $ACT1 = $_POST["ACT1"];
        $ACT2 = $_POST["ACT2"];
        $ACT3 = $_POST["ACT3"];
        $Midterm = $_POST["Midterm"];
        

        do {
            if (empty($userid)) {
                $errorMessage = "userid";
                break;
            }else if (empty($First_name))
            {
                $errorMessage = "1st name";
                break;
            }else if (empty($last_name))
            {
                $errorMessage = "last name";
                break;
            }else if (empty($srcode))
            {
                $errorMessage = "sr";
                break;
            }else if (empty($Quiz1))
            {
                $errorMessage = "1st quiz";
                break;
            }else if (empty($Quiz2))
            {
                $errorMessage = "quiz2";
                break;
            }else if (empty($Quiz3))
            {
                $errorMessage = "quiz3";
                break;
            }else if (empty($ACT1))
            {
                $errorMessage = "act1";
                break;
            }else if (empty($ACT2))
            {
                $errorMessage = "act2";
                break;
            }else if (empty($ACT3))
            {
                $errorMessage = "act3";
                break;
            }else if (empty($Midterm))
            {
                $errorMessage = "Midterms";
                break;
            }

            $stmt = $pdo->prepare("UPDATE users SET First_name = :First_name, last_name = :last_name, srcode = :Srcode, Quiz1 = :Quiz1, Quiz2 = :Quiz2, Quiz3 = :Quiz3, ACT1 = :ACT1, ACT2 = :ACT2, ACT3 = :ACT3, Midterm = :Midterm WHERE userid = :userid");
            $stmt->bindParam(':userid', $userid);
            $stmt->bindParam(':First_name', $First_name);
            $stmt->bindParam(':last_name', $last_name);
            $stmt->bindParam(':Srcode', $srcode);
            $stmt->bindParam(':Quiz1', $Quiz1);
            $stmt->bindParam(':Quiz2', $Quiz2);
            $stmt->bindParam(':Quiz3', $Quiz3);
            $stmt->bindParam(':ACT1', $ACT1);
            $stmt->bindParam(':ACT2', $ACT2);
            $stmt->bindParam(':ACT3', $ACT3);
            $stmt->bindParam(':Midterm', $Midterm);


            $stmt->execute();

            if ($stmt->rowCount() == 0) {
                $errorMessage = "Invalid query: " . $pdo->errorInfo();
                break;
            }

            $successMessage = "Student updated correctly";

            header("location: lms/Adminclass.php");
            exit;

        } while (empty($errorMessage));
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit</title>
    <link rel="stylesheet" href="edit.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <div class="container my-5">
        <h2>Update Grade</h2>

        <?php
        if (!empty($errorMessage)) {
            echo "
            <div class='alert alert-warning alert-dismissible fade show' role='alert'>
                <strong>$errorMessage</strong>
                <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
            </div>
            ";
        }
        ?>  
        <form method="post">
            <input type="hidden" name="userid" value="<?php echo $userid; ?>">
            <div class="form">
                <label class="label">User ID</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" name="userid" value="<?php echo $userid; ?>">
                </div>   
            </div>
<div class="grid-container">
    <div class="form-group">
        <label class="col-sm-3 col-form-label">First Name</label>
        <div class="col-sm-6">
            <input type="text" class="form-control" name="First_name" value="<?php echo $First_name; ?>">
        </div>   
    </div>
    <div class="form-group">
        <label class="col-sm-3 col-form-label">Last Name</label>
        <div class="col-sm-6">
            <input type="text" class="form-control" name="last_name" value="<?php echo $last_name; ?>">
        </div>   
    </div>
    <div class="form-group">
        <label class="col-sm-3 col-form-label">SR Code</label>
        <div class="col-sm-6">
            <input type="text" class="form-control" name="Srcode" value="<?php echo $srcode; ?>">
        </div>   
    </div>
</div>

<div class="grid-container">
            <div class="form-group">
                <label class="col-sm-3 col-form-label">Quiz 1</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" name="Quiz1" value="<?php echo $Quiz1; ?>">
                </div>   
            </div>
            <div class="form-group">
                <label class="col-sm-3 col-form-label">Quiz 2</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" name="Quiz2" value="<?php echo $Quiz2; ?>">
                </div>   
            </div>
            <div class="form-group">
                <label class="col-sm-3 col-form-label">Quiz 3</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" name="Quiz3" value="<?php echo $Quiz3; ?>">
                </div>   
            </div>
</div>
<div class="grid-container">
            <div class="form-group">
                <label class="col-sm-3 col-form-label">Activity 1</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" name="ACT1" value="<?php echo $ACT1; ?>">
                </div>   
            </div>
            <div class="form-group">
                <label class="col-sm-3 col-form-label">Activity 2</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" name="ACT2" value="<?php echo $ACT2; ?>">
                </div>   
            </div>
            <div class="form-group">
                <label class="col-sm-3 col-form-label">Activity 3</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" name="ACT3" value="<?php echo $ACT3; ?>">
                </div>   
            </div>
</div>
            <div class="form-group">
                <label class="col-sm-3 col-form-label">Midterm</label>
                <div class="col-sm-6">
                    <input type="text" class="form-control" name="Midterm" value="<?php echo $Midterm; ?>">
                </div>   
            </div>

            <div class ="form-group">
                <div class="offset-sm-3 col-sm-3 d-grid">
                    <button type="submit" class="btn btn-primary" href="/lms/Adminclass.php">Submit</button>
                </div>
                <div class="col-sm-3 d-grid">
                    <button class=" custom-btn" href="/lms/Adminclass.php">Cancel</button>
                </div>
            </div>

            <?php
            if (!empty ($successMessage) ) {
                echo "
                <div class='row mb-3'>
                    <div class='offset-sm-3 col-sm-6'>
                        <div class='alert alert-success alert-dismissible fade show' role='alert'>
                        <strong>$successMessage</strong>
                        <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
                    </div>
                </div>
                ";
            }
            ?>
            
        </form>
    </div>
</body>
</html>