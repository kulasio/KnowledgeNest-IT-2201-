<?php
include 'config/database.php';
?>
<?php
session_start();
?>

<! DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback</title>
    <style>
        * {
            font-family: "Poppins", sans-serif;
        }
    </style>
    <link rel="stylesheet" href="Adminfeedback.css">
</head>

<body>
<div class="hero">
      <nav>
      <img src="images/logoimg.jpg" alt="Logo" class="logo">
        <h1>KnowledgeNest LMS</h1>
        <ul>
         <li><a href="adminclass.php"><h3>Class</h3></a></li>
          <li><a href="Adminfeedback.php"><h3>Feedback</h3></a></li>

        </ul>
        <img src="images/700kfb.png" class="user-pic" onclick="toggleMenu()">
       
        <div class="sub-menu-wrap" id="subMenu">
        <div class="sub-menu">
            <div class="user-info">
                <img src="images/700kfb.png">
                <?php if(isset($_SESSION['username'])): ?>
                    <h2><?php echo $_SESSION['username']; ?></h2>
                <?php endif; ?>
            </div>
            <hr>
            <a href="AccountConfig.php" class="sub-menu-link">
                <img src="images/setting.png">
                <p>Account Settings</p>
                <span>></span>
            </a>
            <a href="feedback.php" class="sub-menu-link">
                <img src="images/help.png">
                <p>Feedback</p>
                <span>></span>
            </a>
            <a href="index.php" class="sub-menu-link">
                <img src="images/logout.png">
                <p>Logout</p>
                <span>></span>
            </a>
        </div>
    </div>
      </nav>
</div>
<div class = "container my-5">
        <h2>List of Students</h2>
        <br>
        <table class="table">
            <thead>
                <tr>
                    <th>feedbackid</th>
                    <th>studentid</th>
                    <th>Contact No.</th>
                    <th>Email</th>
                    <th>Feedback</th>
                    <th>Date</th>
                <tr>
            </thead>
            <tbody>
                <?php
                $servername = "localhost";
                $username = "root";
                $password = "";
                $database = "lms_final";

                $connection = new mysqli($servername, $username, $password, $database);

                if ($connection->connect_error) {
                    die("Connection failed: " . $connection->connect_error);
                }


                $course_id = $_SESSION['course_id'];
                $sql = "SELECT * FROM feedback where course_id = $course_id"  ;
                $results = $connection->query($sql);

                if (!$results) {
                     die("Invalid query: " . $connection->error);
                }

                while ($row = $results->fetch_assoc()) {
                    echo "
                    <tr>
                         <td>$row[feedbackid]</td>
                         <td>$row[student_id]</td>
                         <td>$row[s_contactnumber]</td>
                         <td>$row[s_email]</td>
                         <td>$row[feedbacktext]</td>
                         <td>$row[feedbackdate]</td>
                         <td>
                            
                        </td>
                    </tr>
                    ";
                }
                ?>

                
                
            </tbody>            
                        
        </table>
                
    <div>
<script>
  let subMenu = document.getElementById("subMenu");
  
  function toggleMenu(){
    subMenu.classList.toggle("open-menu");
  }
  
</script>
  
</body>
</html>