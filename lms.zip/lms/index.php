<?php
include 'config/database.php';

$error_message = ""; // Initialize error message variable

if(isset($_POST['submit'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM students WHERE username = '$username' AND password = '$password'";
    
    $result = mysqli_query($conn, $sql);

    if(mysqli_num_rows($result) == 1){
        session_start();
        $row = mysqli_fetch_assoc($result);
        $_SESSION['username'] = $row['firstname'] . ' ' . $row['lastname'];
        $_SESSION['course_id'] = $row['course_id'];
        header('Location: /lms/homepage.php');
    } else {
        $error_message = "Invalid Username or Password.";
    }
}

if(isset($_POST['Asubmit'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM employee WHERE e_username = '$username' AND e_password = '$password'";
  
    $result = mysqli_query($conn, $sql);

    if(mysqli_num_rows($result) == 1){
        session_start();
        $row = mysqli_fetch_assoc($result);
        $_SESSION['username'] = $row['e_fname'] . ' ' . $row['e_lname'];
        $_SESSION['course_id'] = $row['course_id'];
        $_SESSION['employee_id'] = $row['employee_id'];
        header('Location: /lms/Adminclass.php');
    } else {
        $error_message = "Invalid Username or Password.";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        * {
            font-family: "Poppins", sans-serif;
        }
    </style>
    <link rel="stylesheet" href="index.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>

<body>
    <div class="wrapper">
        <form action="index.php" method="post">
            <h1>Login</h1>
            <div class="input-box">
                <input type="text" placeholder="Username" name="username" required>
                <i class='bx bxs-user'></i>
            </div>

            <div class="input-box">
                <input type="password" placeholder="Password" name="password" required>
                <i class='bx bx-lock' ></i>
            </div>  

            <div class="error-message"><?php echo $error_message; ?></div>
            <style>
                .error-message {
                    color: #fff;
                    margin-top: 5px;
                    margin-bottom: 2.5px;
                    font-size: 14.5px;
                    text-align: center;
                    }
            </style>
            <div class="remember-forgot">
                <a href="forgotpassword.php">Forgot Password?</a>
            </div>
            <button type="submit" name="submit" class="btn">Student</button>
            <button type="submit" name="Asubmit" class="btn">Admin</button>
        </form>
    </div>
</body>
</html>
